Código - documentação automática
********************************

A seguir é apresentada a documnetação gerada automaticamente para os códigos deste projeto.

MSP - EPM Processor Basic UCs -- auto members
=============================================

Este é módulo central, onde estão declaradas os "métodos" para utilização no **EPM Processor**

   .. automodule:: MyEPMProcessorModules
       :members:

       .. Três linhas em branco!
       |
       |

       .. autoexception:: MyEPMProcessorModules.MyExceptionClass
