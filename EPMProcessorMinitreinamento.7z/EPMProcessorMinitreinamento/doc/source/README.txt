﻿*** Tips Windows ***

- Tutorial introdutório sobre Sphinx: http://www.sphinx-doc.org/pt_BR/stable/tutorial.html
   sphinx-quickstart

- Vídeo simples e rápido: https://www.youtube.com/watch?v=LQ6pFgQXQ0Q

- Para rodar a documentação, ir para diretório do Makefile e executar no cmd:
   make clean
   make html

- Sphinx quick-start: http://www.sphinx-doc.org/pt_BR/stable/invocation.html

- Para rodar com o Sphinx do EnvPy3
cd C:\Anaconda2\envs\EnvPy3\Scripts    (No caso de utilizar virtualenv para o Python 3)
sphinx-build -b html C:\Users\mauricio\Projects\EPMProcessorMinitreinamento\doc\source C:\Users\mauricio\Projects\EPMProcessorMinitreinamento\doc\build
