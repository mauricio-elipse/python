# -*- coding: utf-8 -*-

import sys
sys.path.insert(1, r'C:\Users\mauricio\Projects')
sys.path.insert(1, r'C:\Users\mauricio\Projects\EPMProcessorMinitreinamento')

__all__ = ['MyEPMProcessorModules']

import MyEPMProcessorModules
